import { useState } from "react";
import confetti from "canvas-confetti";
import ReactPlayer from "react-player";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function SiddheshwarHungerFoundation() {
  const [showModal, setShowModal] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);
  const [language, setLanguage] = useState("en");

  const handleDonationClick = () => {
    setShowModal(false);
    setShowThankYou(true);
    confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    setTimeout(() => setShowThankYou(false), 4000);
    window.open("https://razorpay.me/@siddheshwarhungerfoundati9740", "_blank");
  };

  const donationData = [
    { month: "Jan", meals: 2400 },
    { month: "Feb", meals: 3000 },
    { month: "Mar", meals: 4200 },
    { month: "Apr", meals: 5100 },
    { month: "May", meals: 6700 },
    { month: "Jun", meals: 8740 },
  ];

  return (
    <div className="font-sans text-gray-800">
      <div className="fixed top-4 right-4 z-50">
        <select
          onChange={(e) => setLanguage(e.target.value)}
          className="border p-1 rounded text-sm"
          value={language}
        >
          <option value="en">English</option>
          <option value="hi">Hindi</option>
          <option value="mr">Marathi</option>
        </select>
      </div>

      {/* rest of the page remains unchanged */}

      {/* Success Metrics Section */}
      <section className="p-6 bg-white text-center">
        <h2 className="text-3xl font-semibold mb-4">Monthly Meals Served</h2>
        <div className="max-w-4xl h-72 mx-auto">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={donationData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="meals" stroke="#f59e0b" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Volunteer Registration */}
      <section className="p-6 bg-gray-50 text-center">
        <h2 className="text-3xl font-semibold mb-4">Join as a Volunteer</h2>
        <form className="max-w-lg mx-auto grid grid-cols-1 gap-4">
          <input type="text" placeholder="Full Name" className="border rounded px-4 py-2" />
          <input type="email" placeholder="Email" className="border rounded px-4 py-2" />
          <input type="text" placeholder="Phone Number" className="border rounded px-4 py-2" />
          <textarea placeholder="Why do you want to volunteer?" rows="4" className="border rounded px-4 py-2"></textarea>
          <button className="bg-yellow-500 text-white px-6 py-2 rounded hover:bg-yellow-600">Submit</button>
        </form>
      </section>

    </div>
  );
}